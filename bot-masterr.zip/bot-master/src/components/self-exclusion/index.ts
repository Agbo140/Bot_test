import SelfExclusion from './self-exclusion';

export default SelfExclusion;
