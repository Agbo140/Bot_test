import SectionMessage from './section-message';
import './section-message.scss';

export default SectionMessage;
