import MenuItems from './menu-items';

export default MenuItems;
