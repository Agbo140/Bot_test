import PageErrorContainer from './page-error-container';

export default PageErrorContainer;
