import Modal from './modal';
import './modal.scss';

export default Modal;
