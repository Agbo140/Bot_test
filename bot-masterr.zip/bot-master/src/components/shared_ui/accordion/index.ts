import Accordion from './accordion';
import './accordion.scss';

export default Accordion;
