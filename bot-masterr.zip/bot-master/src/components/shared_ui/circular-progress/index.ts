import CircularProgress from './circular-progress';
import './circular-progress.scss';

export default CircularProgress;
