import ArrowIndicator from './arrow-indicator';

export default ArrowIndicator;
