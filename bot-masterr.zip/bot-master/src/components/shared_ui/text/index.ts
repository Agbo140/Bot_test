import Text from './text';
import './text.scss';

export default Text;
