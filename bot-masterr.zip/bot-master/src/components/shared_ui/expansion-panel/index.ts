import ExpansionPanel from './expansion-panel';
import './expansion-panel.scss';

export default ExpansionPanel;
