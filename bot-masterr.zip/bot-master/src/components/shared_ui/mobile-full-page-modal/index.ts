import MobileFullPageModal from './mobile-full-page-modal';
import './mobile-full-page-modal.scss';

export default MobileFullPageModal;
