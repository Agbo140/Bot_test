import TickProgress from './tick-progress';
import './tick-progress.scss';

export default TickProgress;
