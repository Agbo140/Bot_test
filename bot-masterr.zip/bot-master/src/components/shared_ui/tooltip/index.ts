import Tooltip from './tooltip';
import './tooltip.scss';

export default Tooltip;
