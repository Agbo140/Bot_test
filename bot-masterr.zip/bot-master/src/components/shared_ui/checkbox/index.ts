import Checkbox from './checkbox';
import './checkbox.scss';

export default Checkbox;
