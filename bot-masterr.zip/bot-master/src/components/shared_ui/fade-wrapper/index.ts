import FadeWrapper from './fade-wrapper';
import './fade-wrapper.scss';

export default FadeWrapper;
