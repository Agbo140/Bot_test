import StaticUrl from './static-url';

export default StaticUrl;
