import Money from './money';
import './money.scss';

export default Money;
