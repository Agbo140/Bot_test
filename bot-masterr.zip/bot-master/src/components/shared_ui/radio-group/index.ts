import RadioGroup from './radio-group';
import './radio-group.scss';

export default RadioGroup;
