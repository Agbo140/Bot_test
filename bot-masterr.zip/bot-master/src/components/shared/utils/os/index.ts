export * from './os_detect';
